package be.eurospacecenter.revise.dto;

public record LobbyEvent(LobbyEventType type, Object payload) {
}
