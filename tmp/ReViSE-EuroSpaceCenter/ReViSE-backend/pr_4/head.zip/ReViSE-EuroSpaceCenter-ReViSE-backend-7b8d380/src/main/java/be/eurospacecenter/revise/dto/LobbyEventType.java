package be.eurospacecenter.revise.dto;

public enum LobbyEventType {
    TEAM_JOINED,
    TEAM_LEFT,
    GAME_STARTED
}
