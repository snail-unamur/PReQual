package be.eurospacecenter.revise.model;

public enum TeamId {
    ING("ING"), MED("MED");

    public final String label;

    TeamId(String label) {
        this.label = label;
    }
}
