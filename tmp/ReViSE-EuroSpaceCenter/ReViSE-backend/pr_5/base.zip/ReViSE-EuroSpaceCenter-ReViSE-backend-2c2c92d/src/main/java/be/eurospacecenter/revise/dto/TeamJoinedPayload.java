package be.eurospacecenter.revise.dto;

public record TeamJoinedPayload(String teamLabel) {
}
