package be.eurospacecenter.revise.model;

import java.util.UUID;

public record Host (UUID id) { }
