package be.eurospacecenter.revise;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReviseApplicationTests {

	@Test
	void contextLoads() {
	}

}
